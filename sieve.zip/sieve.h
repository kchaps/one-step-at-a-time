class sieve
{
  public: 
  void primeNum();
  void read();
  int n;
  int y;
  bool arr[];
};
