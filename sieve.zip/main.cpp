#include <iostream>
#include<vector>
using namespace std;
#include "sieve.h"
int main()
{
  sieve a;
  a.read();
  a.primeNum();
  return 0;
}
